import { Link, useFetcher } from "react-router";
import { Button } from "~/common/components/ui/button";

interface StockCardProps {
  id: string;
  name: string;
  timestamp: string | null;
  purchaseDate: string;
  purchasePrice: number;
  currentPrice: number;
  currentProfit: number;
  currentProfitRate: number;
  hidden: boolean;
  notification_enabled?: boolean;
  showHiddenToggle?: boolean;
  showNotificationToggle?: boolean;
  showModifyButton?: boolean;
  showDeleteButton?: boolean;
  stop_loss_rate:number;
  take_profit_rate:number;
}

export function StockCard({
  id,
  name,
  timestamp,
  purchaseDate,
  purchasePrice,
  currentPrice,
  currentProfit,
  currentProfitRate,
  hidden,
  notification_enabled = true,
  showModifyButton = false,
  showDeleteButton = false,
  showHiddenToggle = false,
  showNotificationToggle = false,
  stop_loss_rate,
  take_profit_rate,
}: StockCardProps) {
  const profitColor = currentProfit >= 0 ? "text-green-600" : "text-red-600";
  const profitRateValue = currentProfitRate ?? 0;
  const profitRateColor = profitRateValue >= 0 ? "text-green-600" : "text-red-600";
  const deleteFetcher = useFetcher();
  const toggleHiddenFetcher = useFetcher();
  const toggleNotificationFetcher = useFetcher();

  return (
    <div className="border rounded-lg p-4 space-y-3">
      <div>
        <h3 className="font-semibold text-lg">{name}</h3>
        <div className="flex gap-4">
          <p className="text-sm text-muted-foreground">구매일: {purchaseDate}</p>
          {timestamp && (
            <p className="text-sm text-muted-foreground">업데이트: {timestamp}</p>
          )}
        </div>
      </div>
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">구매가</span>
          <span className="font-semibold">{(purchasePrice ?? 0).toLocaleString()}원</span>
        </div>        
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">현재가</span>
          <span className="font-semibold">{(currentPrice ?? 0).toLocaleString()}원</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">수익</span>
          <span className={`font-semibold ${profitColor}`}>
            {(currentProfit ?? 0) >= 0 ? "+" : ""}{(currentProfit ?? 0).toLocaleString()}원
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">수익률</span>
          <span className={`font-semibold ${profitRateColor}`}>
            {profitRateValue >= 0 ? "+" : ""}{profitRateValue.toFixed(2)}%
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">익절률</span>
          <span className="font-semibold text-blue-600">
            {(take_profit_rate ?? 0).toFixed(2)}%
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">손절률</span>
          <span className="font-semibold text-red-600">
            {(stop_loss_rate ?? 0).toFixed(2)}%
          </span>
        </div>
      </div>
      <div className="flex gap-2 pt-2 border-t">
        {showModifyButton ? (
          <Button asChild size="sm" variant="outline">
            <Link to={`/stocks/${id}/edit`}>수정</Link>
          </Button>
        ) : null}

        {showHiddenToggle ? (
          <toggleHiddenFetcher.Form method="post" action={`/stocks/${id}/toggle-hidden`}>
            <Button
              type="submit"
              size="sm"
              variant="secondary"
              disabled={toggleHiddenFetcher.state !== "idle"}
            >
              {hidden ? "보이기" : "감추기"}
            </Button>
          </toggleHiddenFetcher.Form>
        ) : null}

        {showNotificationToggle ? (
          <toggleNotificationFetcher.Form method="post" action={`/stocks/${id}/toggle-notification`}>
            <Button
              type="submit"
              size="sm"
              variant={notification_enabled ? "outline" : "secondary"}
              disabled={toggleNotificationFetcher.state !== "idle"}
              title={notification_enabled ? "익절/손절 알림 켜짐 - 끄려면 클릭" : "익절/손절 알림 꺼짐 - 켜려면 클릭"}
            >
              {notification_enabled ? "🔔 알림 ON" : "🔕 알림 OFF"}
            </Button>
          </toggleNotificationFetcher.Form>
        ) : null}
        
        {showDeleteButton ? (
        <deleteFetcher.Form method="post" action={`/stocks/${id}/delete`} className="ml-auto">
          <Button
            type="submit"
            size="sm"
            variant="destructive"
            disabled={deleteFetcher.state !== "idle"}
          >
            삭제
          </Button>
        </deleteFetcher.Form>
        ) : null}
      </div>
    </div>
  );
}
